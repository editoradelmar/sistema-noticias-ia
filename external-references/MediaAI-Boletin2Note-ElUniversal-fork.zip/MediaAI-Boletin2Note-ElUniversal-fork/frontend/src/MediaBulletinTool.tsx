import React, { useState, useCallback, DragEvent, useEffect } from 'react';
import Spinner from './ui/Spinner';

interface PromptType {
  id: string;
  name: string;
  description: string;
}

const MediaBulletinTool: React.FC = () => {
  const [bulletin, setBulletin] = useState('');
  const [article, setArticle] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [promptTypes, setPromptTypes] = useState<PromptType[]>([]);
  const [selectedPromptType, setSelectedPromptType] = useState('cartagena');
  const [isCopied, setIsCopied] = useState(false);
  const [context, setContext] = useState('');

  // Load prompt types on component mount
  useEffect(() => {
    const loadPromptTypes = async () => {
      try {
        const backendUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
        console.log('Attempting to connect to backend at:', backendUrl);
        const response = await fetch(`${backendUrl}/api/prompt-types`);
        if (response.ok) {
          const data = await response.json();
          setPromptTypes(data.prompt_types);
          console.log('Successfully loaded prompt types:', data.prompt_types);
        } else {
          console.error('Failed to load prompt types. Status:', response.status, response.statusText);
        }
      } catch (err) {
        console.error('Error loading prompt types:', err);
        console.error('Backend URL was:', import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000');
      }
    };
    loadPromptTypes();
  }, []);

  const handleFileChange = async (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;

    const allowedTypes = ['application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowedTypes.includes(file.type)) {
      setError('Tipo de archivo no soportado. Use PDF, TXT, DOC o DOCX.');
      return;
    }

    setIsUploading(true);
    setError('');
    
    try {
      const formData = new FormData();
      formData.append('file', file);

      const backendUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
      const response = await fetch(`${backendUrl}/api/upload-file`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setBulletin(data.text);
      setUploadedFile(file);
    } catch (err) {
      setError((err as Error).message);
      console.error(err);
    } finally {
      setIsUploading(false);
    }
  };

  const onDrop = useCallback((event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragOver(false);
    handleFileChange(event.dataTransfer.files);
  }, []);

  const onDragOver = useCallback((event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragOver(true);
  }, []);

  const onDragLeave = useCallback((event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragOver(false);
  }, []);

  const handleGenerate = async () => {
    if (!bulletin.trim()) {
      setError('Por favor, introduce un boletín de medios.');
      return;
    }
    setIsLoading(true);
    setError('');
    setArticle('');
    
    try {
      const backendUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
      const response = await fetch(`${backendUrl}/genera_boletin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bulletin_title: "Boletín de Prensa",
          publication_date: new Date().toISOString().split('T')[0],
          focus_topics: ["Noticias"],
          news_content: bulletin,
          prompt_type: selectedPromptType,
          context: context?.trim() || undefined
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setArticle(data.bulletin);
    } catch (err) {
      setError((err as Error).message);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyToClipboard = async () => {
    if (!article) return;
    
    try {
      // Remove HTML tags for plain text copy
      const plainText = article.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, '');
      await navigator.clipboard.writeText(plainText);
      setIsCopied(true);
      
      // Reset the copied state after 2 seconds
      setTimeout(() => {
        setIsCopied(false);
      }, 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-200">Entrada del Boletín</h3>
        
        {/* Prompt Type Selection */}
        <div className="space-y-2">
          <label htmlFor="prompt-type" className="block text-sm font-medium text-gray-300">
            Tipo de Contenido
          </label>
          <select
            id="prompt-type"
            value={selectedPromptType}
            onChange={(e) => setSelectedPromptType(e.target.value)}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:outline-none transition-colors text-gray-200"
          >
            {promptTypes.map((type) => (
              <option key={type.id} value={type.id}>
                {type.name}
              </option>
            ))}
          </select>
          {promptTypes.find(type => type.id === selectedPromptType) && (
            <p className="text-sm text-gray-400 mt-1">
              {promptTypes.find(type => type.id === selectedPromptType)?.description}
            </p>
          )}
        </div>
        
        {/* Optional Context */}
        <div className="space-y-2">
          <label htmlFor="editor-context" className="block text-sm font-medium text-gray-300">
            Contexto adicional (opcional)
          </label>
          <textarea
            id="editor-context"
            value={context}
            onChange={(e) => setContext(e.target.value)}
            placeholder="Ej.: Puntos clave a enfatizar, público objetivo, tono deseado, ángulo editorial, palabras clave, etc."
            className="w-full h-28 p-3 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:outline-none transition-colors text-gray-200"
          />
          <div className="text-xs text-gray-500 text-right">{context.length} caracteres</div>
        </div>
        
        {/* File Upload Section */}
        <div
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          className={`relative w-full h-48 border-2 border-dashed rounded-lg flex flex-col justify-center items-center text-center p-4 transition-colors duration-300 ${
            isDragOver ? 'border-cyan-500 bg-gray-800/50' : 'border-gray-600 hover:border-gray-500'
          } ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}
        >
          {!uploadedFile && !isUploading && (
            <input
              type="file"
              accept=".pdf,.txt,.doc,.docx"
              onChange={(e) => handleFileChange(e.target.files)}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
          )}
          
          {isUploading ? (
            <div className="text-center">
              <Spinner />
              <p className="mt-2 text-cyan-400 font-semibold">Procesando archivo...</p>
              <p className="text-sm text-gray-400">Extrayendo texto del documento</p>
            </div>
          ) : uploadedFile ? (
            <div className="text-center relative z-10">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto text-green-400">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
              </svg>
              <p className="mt-2 font-semibold text-gray-200">{uploadedFile.name}</p>
              <p className="text-sm text-gray-400">{(uploadedFile.size / 1024 / 1024).toFixed(2)} MB</p>
              <button 
                onClick={() => {
                  setUploadedFile(null);
                  setBulletin('');
                }}
                className="mt-3 px-3 py-1 text-sm text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded border border-red-400/30 hover:border-red-300/50 transition-colors"
              >
                Quitar archivo
              </button>
            </div>
          ) : (
            <div className="text-gray-400">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m6.75 12-3-3m0 0-3 3m3-3v6m-1.5-15H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c0 .621-.504 1.125-1.125 1.125H5.625a1.125 1.125 0 0 1-1.125-1.125V11.25A1.125 1.125 0 0 1 5.625 10.125h4.5L12 8.25Z" />
              </svg>
              <p className="mt-2">Arrastra y suelta tu documento aquí</p>
              <p className="text-sm">o haz clic para buscar</p>
              <p className="text-xs text-gray-500 mt-2">Formatos soportados: PDF, TXT, DOC, DOCX</p>
              <p className="text-xs text-cyan-400 mt-1">Máximo 25MB por archivo</p>
            </div>
          )}
        </div>

        {uploadedFile && (
          <div className="bg-green-900/50 border border-green-700 text-green-300 px-4 py-3 rounded-lg text-sm" role="alert">
            <p><span className="font-bold">✓ Archivo procesado:</span> El texto se ha extraído correctamente y está listo para generar el artículo.</p>
          </div>
        )}

        <div className="text-center text-gray-500 text-sm">
          O
        </div>

        <textarea
          value={bulletin}
          onChange={(e) => setBulletin(e.target.value)}
          placeholder="Pega tu boletín de medios o comunicado de prensa aquí..."
          className="w-full h-64 p-4 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:outline-none transition-colors"
        />
        {error && <p className="text-red-400">{error}</p>}
        <button
          onClick={handleGenerate}
          disabled={isLoading}
          className="w-full flex justify-center items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 px-4 rounded-lg transition duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Spinner />
              Generando...
            </>
          ) : (
            'Generar Noticia'
          )}
        </button>
      </div>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-200">Artículo Generado</h3>
          {article && (
            <button
              onClick={handleCopyToClipboard}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                isCopied 
                  ? 'bg-green-600 text-white' 
                  : 'bg-cyan-600 hover:bg-cyan-700 text-white'
              }`}
            >
              {isCopied ? (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Copiado
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  Copiar
                </>
              )}
            </button>
          )}
        </div>
        <div className="w-full h-80 p-4 bg-gray-800 border border-gray-700 rounded-lg overflow-y-auto prose prose-invert prose-sm max-w-none">
            {article ? (
                <div dangerouslySetInnerHTML={{ __html: article.replace(/\n/g, '<br />') }} />
            ) : (
                <p className="text-gray-500">El artículo generado aparecerá aquí.</p>
            )}
        </div>
      </div>
    </div>
  );
};

export default MediaBulletinTool;
