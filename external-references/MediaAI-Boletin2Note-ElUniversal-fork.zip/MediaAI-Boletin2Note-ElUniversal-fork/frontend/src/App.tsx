import MediaBulletinTool from './MediaBulletinTool';
import './index.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-cyan-400 mb-2">
            Generador de Noticias
          </h1>
          <p className="text-gray-400 text-lg">
            Convierte boletines de prensa en artículos optimizados para SEO
          </p>
        </div>
        
        <div className="max-w-7xl mx-auto">
          <MediaBulletinTool />
        </div>
        
        <div className="mt-12 text-center text-gray-500">
          <p>Powered by Google Gemini AI</p>
        </div>
      </div>
    </div>
  );
}

export default App;
