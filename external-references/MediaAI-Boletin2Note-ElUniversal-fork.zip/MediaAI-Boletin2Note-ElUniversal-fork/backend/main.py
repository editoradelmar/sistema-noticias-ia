import os
import io
import logging
from datetime import datetime
from fastapi.params import Body
import uvicorn
from dotenv import load_dotenv
import google.generativeai as genai
import docx
import shutil
import glob

from fastapi import FastAPI, HTTPException, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional
from PyPDF2 import PdfReader

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bulletin_generator.log'),
        logging.StreamHandler()
    ]
)


# --- Configuration ---
load_dotenv()
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')
STYLE_MANUAL_DIR = os.path.join(os.path.dirname(__file__), 'manual_estilo')

# --- FastAPI App ---
app = FastAPI(
    title="News Bulletin Generator API",
    description="An API to generate news bulletins from provided text using Gemini, following a style manual.",
    version="1.1.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files and templates are not needed for API-only backend
# app.mount("/static", StaticFiles(directory="src/static"), name="static")
# templates = Jinja2Templates(directory="src/templates")

@app.on_event("startup")
async def startup_event():
    logging.info("=" * 80)
    logging.info("INICIANDO SERVIDOR MEDIAAI BULLETIN GENERATOR")
    logging.info("=" * 80)
    logging.info(f"API Key configurada: {'Sí' if GEMINI_API_KEY else 'No'}")
    logging.info(f"Directorio manual de estilo: {STYLE_MANUAL_DIR}")
    
    # Check prompts directory
    prompts_dir = os.path.join(os.path.dirname(__file__), 'prompts')
    logging.info(f"Directorio de prompts: {prompts_dir}")
    if os.path.exists(prompts_dir):
        prompt_files = [f for f in os.listdir(prompts_dir) if f.endswith('.txt')]
        logging.info(f"Archivos de prompts encontrados: {prompt_files}")
    else:
        logging.warning("Directorio de prompts no encontrado")
    
    logging.info("Servidor listo para generar boletines")
    logging.info("=" * 80)

@app.get("/")
async def read_root():
    return {"message": "News Bulletin Generator API", "status": "running", "docs": "/docs"}

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "service": "bulletin-generator", "version": "1.1.0"}

@app.get("/api/prompt-types", tags=["Configuration"])
async def get_prompt_types():
    """
    Returns the available prompt types for bulletin generation.
    """
    return {
        "prompt_types": [
            {
                "id": "cartagena",
                "name": "Sección Cartagena",
                "description": "Contenido local enfocado en información ciudadana, evitando tecnicismos institucionales"
            },
            {
                "id": "sucesos",
                "name": "Sección Sucesos",
                "description": "Noticias de eventos locales con lenguaje claro, evitando términos policivos complejos"
            },
            {
                "id": "farandula",
                "name": "Sección Farándula",
                "description": "Contenido de entretenimiento enfocado en artistas y eventos, atractivo para seguidores"
            },
            {
                "id": "economica",
                "name": "Sección Económica",
                "description": "Información económica traducida a lenguaje comprensible para ciudadanos comunes"
            },
            {
                "id": "deportes",
                "name": "Sección Deportes",
                "description": "Contenido deportivo neutral con terminología accesible para todos los niveles"
            }
        ]
    }

# --- Pydantic Models ---
class BulletinRequest(BaseModel):
    bulletin_title: str = Field(..., example="Weekly Tech News Summary")
    publication_date: str = Field(..., example="2023-10-27")
    focus_topics: List[str] = Field(..., example=["Artificial Intelligence", "Cybersecurity"])
    news_content: str
    prompt_type: Optional[str] = Field(default="cartagena", example="cartagena")
    context: Optional[str] = Field(default=None, example="Puntos clave a enfatizar, público objetivo o consideraciones del editor")

class BulletinResponse(BaseModel):
    bulletin: str

# --- Helper Functions ---
def get_style_manual_content():
    """Reads style manual content from multiple files in the manual_estilo directory.
    Supports PDF, TXT, and DOCX files."""
    try:
        if not os.path.exists(STYLE_MANUAL_DIR):
            raise HTTPException(status_code=500, detail=f"Style manual directory not found at {STYLE_MANUAL_DIR}")
        
        # Get all supported files from the directory
        supported_extensions = ['*.pdf', '*.txt', '*.docx', '*.doc']
        all_files = []
        
        for extension in supported_extensions:
            pattern = os.path.join(STYLE_MANUAL_DIR, extension)
            all_files.extend(glob.glob(pattern))
        
        if not all_files:
            raise HTTPException(status_code=500, detail=f"No supported files found in {STYLE_MANUAL_DIR}")
        
        # Extract text from all files
        combined_text = ""
        for file_path in sorted(all_files):  # Sort for consistent order
            filename = os.path.basename(file_path)
            try:
                file_text = extract_text_from_file(file_path, filename)
                combined_text += f"\n--- Manual de Estilo: {filename} ---\n"
                combined_text += file_text
                combined_text += "\n\n"
            except Exception as e:
                logging.warning(f"Could not read {filename}. Error: {e}")
                continue
        
        if not combined_text.strip():
            raise HTTPException(status_code=500, detail="No content could be extracted from style manual files")
        
        return combined_text
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading style manual: {e}")

def extract_text_from_pdfs(pdf_files):
    """Extracts text content from a list of PDF file streams."""
    full_text = ""
    for pdf in pdf_files:
        try:
            reader = PdfReader(pdf['content'])
            text = f"\n--- Document Reference: {pdf['name']} ---\n"
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text
            text += "\n"
            full_text += text
        except Exception as e:
            logging.warning(f"Could not read {pdf['name']}. Error: {e}")
    return full_text

def extract_text_from_file(file_path: str, filename: str) -> str:
    """Extract text from different file types."""
    try:
        if filename.lower().endswith('.pdf'):
            with open(file_path, 'rb') as f:
                reader = PdfReader(f)
                text = ""
                for page in reader.pages:
                    text += page.extract_text()
                return text
        elif filename.lower().endswith('.txt'):
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        elif filename.lower().endswith(('.doc', '.docx')):
            doc = docx.Document(file_path)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            return text
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {e}")

def load_prompt_from_file(prompt_type: str) -> str:
    """Load prompt template from file in the prompts directory."""
    try:
        prompts_dir = os.path.join(os.path.dirname(__file__), 'prompts')
        file_path = os.path.join(prompts_dir, f"{prompt_type}.txt")
        
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        else:
            # Fallback to cartagena if file doesn't exist
            fallback_path = os.path.join(prompts_dir, "cartagena.txt")
            if os.path.exists(fallback_path):
                with open(fallback_path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                raise FileNotFoundError(f"No prompt file found for {prompt_type}")
    except Exception as e:
        logging.error(f"Error loading prompt file for {prompt_type}: {e}")
        # Return a basic fallback prompt
        return """**TAREA:** Eres un redactor profesional. Convierte el boletín de prensa en una nota periodística clara y objetiva."""

def get_prompt_template(prompt_type: str, request: BulletinRequest, style_manual: str) -> str:
    """Returns the appropriate prompt template based on the prompt type."""
    
    base_prompt = load_prompt_from_file(prompt_type)
    
    # Build context section if provided
    context_section = ""
    if request.context and request.context.strip():
        context_section = f"""
    **CONTEXTO ADICIONAL DEL EDITOR:**
    {request.context}
    --- FIN DEL CONTEXTO ADICIONAL ---
    """
    
    return f"""
    1. ROL Y OBJETIVO
        Actúa como un periodista profesional y redactor de contenidos digitales. Tu tarea es procesar la información proporcionada y transformarla en una nota periodística completa, siguiendo de manera estricta el formato de respuesta y el manual de estilo detallados a continuación.

    2. FORMATO DE RESPUESTA REQUERIDO
        Tu respuesta debe estructurarse obligatoriamente en las siguientes cinco secciones, sin excepción:
        Título SEO:
        Título para Redes Sociales:
        Sumario:
        Cuerpo del Texto:
        Copy para Redes Sociales:

    3. INSTRUCCIONES DE ESTILO Y FORMA (manual):
        Estas son instrucciones detalladas que debes seguir estrictamente al redactar la nota periodística:
        --- INICIO DEL MANUAL DE ESTILO E INDICACIONES ESPECIFICAS ---
        {style_manual}
        --- FIN DEL MANUAL DE ESTILO E INDICACIONES ESPECIFICAS ---

    4. INSTRUCCIONES PARA CADA TIPO DE CATEGORIA:
        Tienes que tomar en cuenta la redacción de la nota periodística de acuerdo con la categoria seleccionada: 
        --- INICIO DE INSTRUCCIONES POR CATEGORIA---
        {base_prompt}
        --- FIN DE INSTRUCCIONES POR CATEGORIA ---

    5. INSTRUCCIONES DE CONTEXTO ADICIONAL:
        Si el usuario proporciona un contexto adicional, debes considerarlo al redactar la nota periodística.
        {context_section}
        
    6. CONTENIDO DEL BOLETIN:
        --- INICIO DEL CONTENIDO DE LA NOTA ---
        {request.news_content}
        --- FIN DEL CONTENIDO DE LA NOTA ---

    7. NOTA GENERADA:
        Sólo responde con la nota periodística generada. Nunca contestes como un LLM dando una respuesta.
        No utilices símbolos especiales: * o # en la nota generada.
        --- INICIO DE LA NOTA GENERADA ---
        
    """

def generate_with_gemini(api_key, prompt):
    """Generates content using the Gemini API."""
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-2.0-flash-exp')
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gemini API error: {e}")

# --- API Endpoint ---
@app.post("/genera_boletin", response_model=BulletinResponse, tags=["Bulletin"])
async def genera_boletin(request: BulletinRequest):
    """
    Generates a news bulletin by processing provided text content based on a local style manual.
    """
    try:
        # Check if API key is configured
        if not GEMINI_API_KEY:
            raise HTTPException(status_code=500, detail="GEMINI_API_KEY not configured")
        
        # 1. Get style manual
        style_manual = get_style_manual_content()

        # 2. Build the prompt using the selected prompt type
        prompt = get_prompt_template(request.prompt_type, request, style_manual)

        # Log the prompt being sent
        logging.info("=" * 80)
        logging.info("PROMPT ENVIADO A GEMINI:")
        logging.info("=" * 80)
        logging.info(f"Tipo de prompt: {request.prompt_type}")
        logging.info(f"Título: {request.bulletin_title}")
        logging.info(f"Contexto adicional: {'Sí' if request.context and request.context.strip() else 'No'}")
        logging.info("Prompt completo:")
        logging.info(prompt)
        logging.info("=" * 80)

        # 3. Generate content with Gemini
        generated_content = generate_with_gemini(GEMINI_API_KEY, prompt)

        return {"bulletin": generated_content}
    
    except Exception as e:
        logging.error(f"Error in genera_boletin: {e}")
        raise HTTPException(status_code=500, detail=f"Error generating bulletin: {str(e)}")

@app.post("/api/upload-file", tags=["File Upload"])
async def upload_file(file: UploadFile = File(...)):
    """
    Upload and process a file (PDF, TXT, DOC, DOCX) to extract text content.
    """
    try:
        # Check file type
        allowed_extensions = ['.pdf', '.txt', '.doc', '.docx']
        file_extension = os.path.splitext(file.filename)[1].lower()
        
        if file_extension not in allowed_extensions:
            raise HTTPException(
                status_code=400, 
                detail=f"File type not supported. Allowed: {', '.join(allowed_extensions)}"
            )
        
        # Create uploads directory if it doesn't exist
        uploads_dir = os.path.join(os.path.dirname(__file__), "uploads")
        os.makedirs(uploads_dir, exist_ok=True)
        
        # Save uploaded file temporarily
        file_path = os.path.join(uploads_dir, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Extract text from file
        extracted_text = extract_text_from_file(file_path, file.filename)
        
        # Clean up temporary file
        os.remove(file_path)
        
        return {
            "success": True,
            "filename": file.filename,
            "text": extracted_text,
            "length": len(extracted_text)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        # Clean up file if it exists
        if 'file_path' in locals() and os.path.exists(file_path):
            os.remove(file_path)
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

# --- Main execution ---
if __name__ == "__main__":
    # This allows running the app with `python main.py`
    # For development, it's better to use: uvicorn main:app --reload
    uvicorn.run(app, host="0.0.0.0", port=8000)
