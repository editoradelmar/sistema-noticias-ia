# Simple Bulletin App

Aplicación web que transforma boletines de prensa y comunicados en artículos periodísticos optimizados.

## Estructura del Proyecto

```
simple_bulletin_app/
├── backend/
│   ├── main.py              # API FastAPI principal
│   ├── requirements.txt     # Dependencias Python
│   ├── .env                # Variables de entorno
│   └── manual_estilo/      # Guías editoriales
├── frontend/
│   ├── src/
│   │   ├── MediaBulletinTool.tsx  # Componente principal
│   │   ├── ui/Spinner.tsx         # Componente spinner
│   │   ├── App.tsx               # Aplicación React
│   │   └── vite-env.d.ts        # Definiciones TypeScript
│   ├── package.json
│   └── vite.config.ts
└── README.md               # Documentación del proyecto
```

## Instalación y Configuración

### 1. Configurar Backend
```bash
cd simple_bulletin_app/backend

# Editar .env y agregar tu GEMINI_API_KEY
# GEMINI_API_KEY=tu_api_key_aqui

# Instalar dependencias de Python
pip install -r requirements.txt
```

### 2. Configurar Frontend
```bash
cd simple_bulletin_app/frontend

# Instalar dependencias de Node.js
npm install
```

### 3. Iniciar Aplicación

#### Terminal 1 - Backend (FastAPI)
```bash
cd simple_bulletin_app/backend
python main.py
```
O alternativamente:
```bash
cd simple_bulletin_app/backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

#### Terminal 2 - Frontend (React)
```bash
cd simple_bulletin_app/frontend
npm run dev
```

### 4. Acceder
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **Documentación API**: http://localhost:8000/docs

## Características

- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: FastAPI + Google Gemini
- **Funcionalidad**: Conversión de boletines a artículos optimizados
- **Diseño**: Interfaz de dos columnas con carga de archivos
- **API**: Endpoints `/genera_boletin` y `/api/upload-file`

## Requisitos

- Python 3.8+
- Node.js 16+
- Google Gemini API Key

## Uso

1. Arrastra y suelta archivos (PDF, TXT, DOC, DOCX) o pega texto directamente
2. Hacer clic en "Generar Noticia"
3. El artículo optimizado aparece en el panel derecho
4. Los archivos se procesan automáticamente y se extrae el texto
